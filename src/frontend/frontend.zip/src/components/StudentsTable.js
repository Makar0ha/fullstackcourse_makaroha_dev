import { Badge, Form, Input, InputNumber, Popconfirm, Radio, Table, Tag, Typography } from "antd";
import React, { useState } from "react";
import { deleteStudent } from "./client";
import { errorNotification, successNotification } from "./Nottification";
import TheAvatar from "./TheAvatar";


const removeStudent = (studentId, fetchStudents, data, setStudents) => {
    deleteStudent(studentId).then(() => {
        successNotification("Student deleted", `Student with id - ${studentId} was deleted`);
        console.log(data.lenght);
        fetchStudents();
        console.log(data.lenght);
        setStudents(data);
        console.log(data.lenght);
    }).catch(err => {
        console.log(err.response);
        err.response.json().then(res => {
            console.log(res);
            errorNotification("There was an issue", `${res.message} [${res.status}] [${res.error}]`);
        });
    });
}

const changeStudent = (student, setShowEditStudentDrawer) => {
    alert("Student" + student.name);
    // console.log(showEditStudentDrawer);
    // setShowEditStudentDrawer(true);
    // console.log(showEditStudentDrawer);

}

const EditableCell = ({
    editing,
    dataIndex,
    title,
    inputType,
    record,
    index,
    children,
    ...restProps
}) => {
    const inputNode = inputType === 'number' ? <InputNumber /> : <Input />;
    return (
        <td {...restProps}>
            {editing ? (
                <Form.Item
                    name={dataIndex}
                    style={{
                        margin: 0,
                    }}
                    rules={[
                        {
                            required: true,
                            message: `Please Input ${title}!`,
                        },
                    ]}
                >
                    {inputNode}
                </Form.Item>
            ) : (
                children
            )}
        </td>
    );
};

const StudentsTable = ( {students, setStudents, fetchStudents} ) => {
    // for (let i = 0; i < students.length; i++) {
    //     originData.push({
    //       key: i.toString(),
    //       name: students[i].name,
    //       email: students[i].email,
    //       gender: students[i].gender,
    //     });
    //   }
    const [form] = Form.useForm();
    const [data, setData] = useState(students);
    const [fetching, setFetching] = useState(false);
    const [editingKey, setEditingKey] = useState('');
    const isEditing = (record) => record.key === editingKey;
    const edit = (record) => {
        form.setFieldsValue({
            name: '',
            age: '',
            address: '',
            ...record,
        });
        setEditingKey(record.key);
        changeStudent(record);
    };
    const cancel = () => {
        setEditingKey('');
    };
    const save = async (key) => {
        try {
            const row = await form.validateFields();
            const newData = [...data];
            const index = newData.findIndex((item) => key === item.key);
            if (index > -1) {
                const item = newData[index];
                newData.splice(index, 1, {
                    ...item,
                    ...row,
                });
                setData(newData);
                setEditingKey('');
            } else {
                newData.push(row);
                setData(newData);
                setEditingKey('');
            }
        } catch (errInfo) {
            console.log('Validate Failed:', errInfo);
        }
    };
    const columns = [
        {
            title: '',
            dataIndex: 'avatar',
            key: 'avatar',
            render: (text, record) => <TheAvatar name={record.name} />
        },
        {
            title: 'Id',
            dataIndex: 'id',
            key: 'id',
        },
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
            editable: true
        },
        {
            title: 'Email',
            dataIndex: 'email',
            key: 'email',
            editable: true,
        },
        {
            title: 'Gender',
            dataIndex: 'gender',
            key: 'gender',
            editable: true,
        },
        {
            title: 'Action',
            dataIndex: 'action',
            key: 'action',
            render: (_, record) => {
                const editable = isEditing(record);
                return editable ? (

                    <span>
                        <Typography.Link
                            onClick={() => save(record.key)}
                            style={{
                                marginRight: 8,
                            }}
                        >
                            Save
                        </Typography.Link>
                        <Popconfirm title="Sure to cancel?" onConfirm={cancel}>
                            <a>Cancel</a>
                        </Popconfirm>
                    </span>
                ) : (
                    <Radio.Group 
                    optionType="button" 
                    >
                        <Popconfirm
                            placement="topLeft"
                            title={`Are you sure to delete ${record.name}?`}
                            onConfirm={() => {removeStudent(record.id, fetchStudents, data, setStudents)}}
                            okText="Yes"
                            cancelText="No"
                        >
                            <Radio.Button value="delete">Delete</Radio.Button>
                        </Popconfirm>
                        <Popconfirm
                            placement="topLeft"
                            title={`Are you sure to change data for ${record.name}?`}
                            onConfirm={() => edit(record)}
                            okText="Yes"
                            cancelText="No"
                            disabled={editingKey !== ''}
                        >
                            <Radio.Button value="edit">Edit</Radio.Button>
                        </Popconfirm>
                    </Radio.Group>

                );
            },
        },
    ];

    const mergedColumns = columns.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record) => ({
                record,
                inputType: col.dataIndex === 'age' ? 'number' : 'text',
                dataIndex: col.dataIndex,
                title: col.title,
                editing: isEditing(record),
            }),
        };
    });
    return (
        <Form form={form} component={false}>
            <Table
                rowKey={(record) => record.id}
                components={{
                    body: {
                        cell: EditableCell,
                    },
                }}

                dataSource={data}
                columns={mergedColumns}
                rowClassName="editable-row"
                pagination={{ pageSize: 50 }}
                scroll={{ y: 560 }}
                bordered
                title={() =>
                    <div style={{ textAlign: 'right' }}>
                        <Tag
                        >Number of students
                        </Tag>
                        <Badge
                            className="site-badge-count-109"
                            count={data.length} />
                    </div>
                }
            />
        </Form>
    );
};
export default StudentsTable;